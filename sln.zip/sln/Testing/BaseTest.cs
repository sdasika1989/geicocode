﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{  
   public class BaseTest
    {
        public static IWebDriver driver;

        public void initializeDriver()
        {
            driver = new ChromeDriver();
        }

        public void NavigateToURL(string sURL)
        {
            driver.Navigate().GoToUrl(sURL);
        }
    }
}
