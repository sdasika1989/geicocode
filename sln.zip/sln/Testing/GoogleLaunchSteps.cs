﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;


namespace Testing
{
    [Binding]
    public class GoogleLaunchSteps : BaseTest
    {
        PageObjects page;

        [BeforeScenario]
        public void setup()
        {
            initializeDriver();
            page = new PageObjects();
        }

        [Given(@"Launch Browser Chrome")]
        public void GivenLaunchBrowserChrome()
        {
            Console.WriteLine("Brower Initialization");            
        }
        
        [When(@"Navigate to Google")]
        public void WhenNavigateToGoogle()
        {
            Console.WriteLine("Navigate to URL");
            NavigateToURL("https://google.co.in");
        }

        [Then(@"Home page is displayed")]

        public void ThenHomePageIsDisplayed()
        {
            Console.WriteLine("Verify Home Page Displayed");
            Assert.IsTrue(page.SearchBox.Displayed);
        }

        [When(@"Search with ""(.*)""")]
        public void WhenSearchWith(string p0)
        {
            Console.WriteLine("Search with.. ");
            page.SearchBox.SendKeys(p0);
            page.GoogleSearch.Click();           
        }

        [Then(@"Total links should be (.*)")]
        public void ThenTotalLinksShouldBe(int p0)
        {
            Console.WriteLine("Verify Links returned and Compare");           
            Assert.AreEqual(page.getLinksCount(), p0);
        }
        [Then(@"Result should displayed")]
        public void ThenResultShouldDisplayed()
        {
            Console.WriteLine("Verify results displayed");
            Assert.IsTrue(page.ResultsString.Displayed);
        }
        






    }
}
