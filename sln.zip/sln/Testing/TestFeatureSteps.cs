﻿using System;
using TechTalk.SpecFlow;

namespace Testing
{
    [Binding]
    public class TestFeatureSteps
    {
        [Given]
        public void GivenIHaveEntered_P0_IntoTheCalculator(int p0)
        {
           
        }
        
        [When]
        public void WhenIPressAdd()
        {
           
        }
        
        [Then]
        public void ThenTheResultShouldBe_P0_OnTheScreen(int p0)
        {
            
        }
    }
}
