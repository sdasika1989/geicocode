﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
    public class PageObjects
    {
        public PageObjects()
        {
            PageFactory.InitElements(BaseTest.driver, this);
        }
       
        [FindsBy (How = How.Name, Using="q")]
        public IWebElement SearchBox { get; set; }

        [FindsBy(How = How.Name, Using = "btnK")]
        public IWebElement GoogleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "resultStats")]
        public IWebElement ResultsString { get; set; }

        [FindsBy(How = How.XPath, Using = ".//a")]
        public IList<IWebElement> LinksCount { get; set; }

        public void searchWithText(string sText)
        {
            SearchBox.SendKeys(sText);
            GoogleSearch.Click();
        }

        public int getLinksCount()
        {
            return LinksCount.Count;
        }


    }
}
