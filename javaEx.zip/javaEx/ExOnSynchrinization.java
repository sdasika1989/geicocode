package javaEx;


class Tabel{
synchronized void printTable(int num){
	for(int i=0;i<=num;i++){
		System.out.println(num*i);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
	
}

class MyThread1 extends Thread{
	/*Tabel table;
		public MyThread1(Tabel table) {
			this.table=table;
		}
		public void run(){
			table.printTable(10);
		}*/
}
class MyThread2 extends Thread{
	/*Tabel table;
		public MyThread2(Tabel table) {
			this.table=table;
		}
		public void run(){
			table.printTable(100);
		}*/
}
public class ExOnSynchrinization {
	public static void main(String[] args) {

		 final Tabel t = new Tabel();
//		MyThread1 theread1 =new MyThread1(t);
		//Synchronzed method by using annonymaous class
		MyThread1 t1 =new MyThread1(){
			public void run(){
				t.printTable(10);
			}
		};
//		MyThread2 theread2=new MyThread2(t);
		MyThread2 t2 =new MyThread2(){
			public void run(){
				t.printTable(10);
			}
		};
		t1.start();
		t2.start();
		
		
		
		
	}

}
