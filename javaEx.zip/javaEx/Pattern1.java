package javaEx;

public class Pattern1 {
	public static void main(String[] args) {
		Test();
	}
		

		
public static int Test() {
	int i,j;
	for (i=1;i<=4;i++) {
		for (j=1;j<=i;j++) {
			if(j<i) 
				System.out.print("*"); 
			else
					System.out.print(i);
		}
		System.out.print(" \n");
	}
	for (i=4;i>=1;i--) {
		for (j=1;j<=i;j++) {
			if(j<i) 
				System.out.print(i); else 
					System.out.print(i);
		}
		System.out.print(" \n");
	}
	return 0;
}
}