package javaEx;

public class TypeCasting {
	public static void main(String[] ar)
	{
		int a=10;
//		float f=13.23f;
		char c='A';
		double d=34.5465765765765;
//		boolean b=true;
		int a1=c;
		long l=656;
		char c1=(char)8;
	     long l1=a;
	     int f1=(int)d;
	     System.out.println(a1+l+c1+l1+f1);
	}

}
