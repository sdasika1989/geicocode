package javaEx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestChIsVowelOrNot {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter a Charachter::");
		char ch;
		ch=(char)br.read();
		if(ch=='a'||ch=='A'||ch=='e'||ch=='E'){
			System.out.println("vowel");
		}else{
			System.out.println("Constant");
		}
	}
}
