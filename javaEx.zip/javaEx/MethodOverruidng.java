package javaEx;

public class MethodOverruidng {
	int a=15,b=10;
	public void add(int a,int b)
	{
		System.out.println("parent class add() method");
		this.a=a;
		this.b=b;
		System.out.println(this.a+this.b);
	}

}
class MethodOverruidngImpl extends MethodOverruidng
{
	int a=100,b;
	
	public void add(int a,int b)
	{   
		System.out.println("child class add() method");
		this.a=a;
		this.b=b;
		super.a=100;
		System.out.println(this.a+this.b);
		
	}
	public void print()
	{
		super.add(10, 20);
	}
	public static void main(String[] ar)
	{
		 MethodOverruidngImpl moi=new  MethodOverruidngImpl();
		System.out.println(moi.a);
		System.out.println(moi.b);
		moi.add(20, 30);
		System.out.println(moi.a);
		System.out.println(moi.b);
		moi.print();
		
	}
}
