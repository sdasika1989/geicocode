package javaEx;

public class JbaraInt {

	/**
	 * @param args
	 *output
	 */
	public static void main(String[] args) {
		String s1 = "abc";
        String s2 = "abc";
        String s3= new String("abc");
       if (s1 == s2) {
		System.out.println("cool");
	}else{
		System.out.println("not cool");
	}
       
       if (s1==s3) {
		System.out.println("cool");
	}else{
		System.out.println("not cool");
	}

		
	}
	

}
