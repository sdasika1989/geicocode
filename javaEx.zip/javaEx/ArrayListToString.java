package javaEx;

import java.util.ArrayList;
import java.util.List;

//interview qts
	 
	public class ArrayListToString {
	 
	public static void main(String args[]){
	 
	    List<String> al = new ArrayList<String>();
	 
	    al.add("One");
	    al.add("Two");
	    al.add("Three");
	    al.add(null);
	    al.add("Four");
	    al.add("Five");
	 
	    String[] stringArrayObject = new String[al.size()];
	    System.out.println("stringArrayObject"+stringArrayObject);
	    al.toArray(stringArrayObject);
	 
	    for(String temp : stringArrayObject)
	    System.out.println("temp::"+temp);
	 
	}
	}


