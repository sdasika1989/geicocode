package javaEx;

public class Fibonacci {
	static int fibonocci(int number) {

		int i = 0;
		int j = 1, c;
		for (int k = 0; k <= number; k++) {
			c = i + j;// 1
			i = j;// 1
			j = c;// 1
			System.out.println("J value" + j);
		}
		return j;
	}

	public static void main(String[] args) {
		int f = fibonocci(10);
	}

}
