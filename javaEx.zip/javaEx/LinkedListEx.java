package javaEx;

import java.util.LinkedList;
import java.util.Vector;

public class LinkedListEx {
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		LinkedList<Comparable>  lList = new LinkedList<Comparable>();
		@SuppressWarnings("rawtypes")
		Vector<Comparable> vector = new Vector<Comparable>();
		lList.add("Rafi");
		lList.add(null);
		lList.add("khan");
		lList.add(30);
		lList.set(2,"rk");
		lList.removeLast();
		lList.add(55);
		lList.add(9);
		lList.add(11);
		System.out.println("List ::"+lList);
		System.out.println("List size::"+lList.size());
		vector.add(33);
		vector.addAll(lList);
		vector.remove(lList.remove(3));
		vector.add(66);
		vector.add(33);
		vector.removeElementAt(1);
		System.out.println("Vector ::"+vector);
		System.out.println("Vector size::"+vector.size());
			}

}
