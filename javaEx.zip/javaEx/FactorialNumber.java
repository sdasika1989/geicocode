package javaEx;

public class FactorialNumber {
	static int fact(int number){
		int f=1;
		for (int i = 1; i <=number; i++) {
			f=f*i;
			System.out.println("f:"+f);
		}
		return f;
	}
	public static void main(String[] args) {
		int result=fact(5);
		System.out.println("F value"+result);
	}

}

