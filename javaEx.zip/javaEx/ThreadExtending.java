package javaEx;

public class ThreadExtending extends Thread {
	
	ThreadExtending()
	{
		super();
	}
	public void run()
	{
		for(int i=0;i<100;i++)
		{
			System.out.println(i);
		}
	}
  public static void main(String[] ar)
  { try
    {
	  ThreadExtending th=new ThreadExtending();
	  th.start();
	  System.out.println("priority="+th.getPriority());
	 Thread.yield();
	  ThreadExtending th1=new ThreadExtending();
	  th1.start();
	  System.out.println(th1.getName());
    }catch(Exception e)
  {
	 e.printStackTrace();
  }
  }
}
