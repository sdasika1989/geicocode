package javaEx;


/**
 * Inter Thread Communication example
 * @author Rafi
 *
 */
 class Customer{
	int amount=0;
	int flag=0;
	
	public synchronized int withDrawl(int amount){
		System.out.println(Thread.currentThread().getName()+"is going to With Drawl");
		if(flag == 0){
			try {
				System.out.println("Waiting.......");
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
			this.amount=amount;
			amount-=amount;
			System.out.println("with Drawl Compleated...");
			return amount;
	}
	
public synchronized void deposit(int amt){
		System.out.println(Thread.currentThread().getName()+"is going to deposit");
			this.amount+=amt;
			notifyAll();
			System.out.println("Depost Compleated...");
			flag=1;
	}
}

public class SyncronizedMethod {
	public static void main(String[] args) {
		final Customer customer = new Customer();
		Thread t1 = new Thread(){
			public void run(){
				customer.withDrawl(1000);
				System.out.println("After with Drawl Amount is::"+customer.amount);
			}
		};
		
		Thread t2 = new Thread(){
			public void run(){
				customer.deposit(5000);
				System.out.println("After Deposit Amount is::"+customer.amount);
			}
		};

		t1.start();
		t2.start();
	}
}
