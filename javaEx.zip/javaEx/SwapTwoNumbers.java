package javaEx;

public class SwapTwoNumbers {
	
	public static void main(String[] args) {
		int a=40,b=5;
		a=a*b;
		b=a/b;
		a=a/b;
		System.out.println("a"+a);
		System.out.println("b"+b);
	}

}
