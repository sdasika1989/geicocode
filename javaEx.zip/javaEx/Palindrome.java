package javaEx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Palindrome {
public static void main(String...args) throws NumberFormatException, IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	int a=0;
	System.out.println("Enter a Number::");
	a=Integer.parseInt(br.readLine());
		int n=a,b=a,rev=0;
		while(n>0){
			a=n%10;
			rev=rev*10+a;
			n=n/10;
			
		}
		if(rev==b)
			System.out.println("palindrome number");
		else
			System.out.println("not palindrome number");
		
	}
}
