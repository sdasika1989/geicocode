package javaEx;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class Remove_Duplicate_Arrays {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer [] input = {1,2,3,3,4,4};
		Set<Integer> tmp = new LinkedHashSet<Integer>();
		for (Integer each : input) {
		    tmp.add(each);
		}
		System.out.println(tmp);
		/*Integer [] output = new Integer[tmp.size()];
		int i = 0;
		for (Integer each : tmp) {
		    output[i++] = each;
		}
		System.out.println(Arrays.toString(output));*/
	}

}
