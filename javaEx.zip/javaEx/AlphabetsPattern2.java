package javaEx;

public class AlphabetsPattern2 
{
	public static void main(String[] args)
	{
    
		int number = 10;
		int asciiNumber = 64;
		for (int i = 1; i <= number; i++) 
		{
			for (int j = 1; j <= i; j++) 
			{
				asciiNumber = asciiNumber+1;
				System.out.print((char) (asciiNumber)+" ");
			}
			System.out.println();
		}
	}

}


/*

A 
B C 
D E F 
G H I J 
K L M N O 
P Q R S T U 
V W X Y Z [ \ 
] ^ _ ` a b c d 
e f g h i j k l m 
n o p q r s t u v w 

*/