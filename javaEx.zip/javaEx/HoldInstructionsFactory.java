/*package javaEx;

import com.vsoftcorp.coresoft.model.DepositAccountIntf;
import com.vsoftcorp.coresoft.model.HoldInstructions;
import com.vsoftcorp.coresoft.model.hibernate.HoldInstructionsHB;

public class HoldInstructionsFactory {

    private static HoldInstructionsFactory holdInstructionsFactory;

    private HoldInstructionsFactory() {

    }

    public static synchronized HoldInstructionsFactory getInstance() {
        if (holdInstructionsFactory == null) {
            holdInstructionsFactory = new HoldInstructionsFactory();
        }
        return holdInstructionsFactory;
    }

    public HoldInstructions getHoldInstructions(
            DepositAccountIntf theDepositAccount) {
        return new HoldInstructionsHB(theDepositAccount);
    }
}
*/