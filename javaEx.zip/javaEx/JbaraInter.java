package javaEx;

public class JbaraInter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JbaraInter.test();
	}
	public static void test() {
		String s1="hello";
		while (true) {
			for (; ;) {
				if (s1.equals("hello")) 
					break;
			}
			System.out.println("hellooo");
			
		}
//o/p
	}

}
