/*package com.vsoftcorp.coresoft.factory;

import com.vsoftcorp.coresoft.model.DepositAccountIntf;
import com.vsoftcorp.coresoft.model.StopPaymentInstructions;
import com.vsoftcorp.coresoft.model.hibernate.StopPaymentInstructionsHB;

public class StopPaymentInstructionsFactory {

    private static StopPaymentInstructionsFactory stopPaymentInstructionsFactory;

    private StopPaymentInstructionsFactory() {

    }

    public static synchronized StopPaymentInstructionsFactory getInstance() {
        if (stopPaymentInstructionsFactory == null) {
            stopPaymentInstructionsFactory = new StopPaymentInstructionsFactory();
        }
        return stopPaymentInstructionsFactory;
    }

    public StopPaymentInstructions getStopPaymentInstructions(
            DepositAccountIntf theDepositAccount) {
        System.out.println("theDepositAccount ::: " + theDepositAccount);
        return new StopPaymentInstructionsHB(theDepositAccount);
    }
}
*/