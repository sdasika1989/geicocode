package javaEx;

public class MethodOverLodingDemo {
	int a;
	int c;
	
	public void area(int a)
	{   this.a=20;
		System.out.println(a*a);
		
	}
	public void area(int l,int b)
	{
		System.out.println(l*b);
		this.area(5,10,2);
		System.out.println(this.c);
		
	}
	public void area(int l,int b,int h)
	{
		System.out.println(l*b*h);
	}
	public static void  main(String[] ar)
	{
		MethodOverLodingDemo  mod=new MethodOverLodingDemo();
		System.out.println("area of a square is");
		//mod.area(10);
		System.out.println("area of the rectangle is");
		mod.area(10,8);
		System.out.println("area of the triangle is");
		mod.area(5,7,9);
			}

}
