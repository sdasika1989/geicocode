package javaEx;

import java.util.HashSet;

public class TreesetDemo {
	
	public static void main(String[] args) {
		HashSet<String>  treeSeta= new HashSet<String>();
		treeSeta.add("P");
		treeSeta.add("L");
		treeSeta.add("P");
		treeSeta.add("K");
/*		treeSet.add(new StringBuffer("a"));
		treeSet.add(new StringBuffer("V"));
		treeSet.add(new StringBuffer("D"));
		treeSet.add(new StringBuffer("J"));
		treeSet.add(new StringBuffer("R"));
*/		System.out.println("Treeset::"+treeSeta);
//treeSet.add(null);
	}

}
