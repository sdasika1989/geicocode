package javaEx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicateArrays {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// ////this code is to remove duplicate values
		int array[] = { 1, 2, 3, 4, 5, 2, 3, 4, 5, 3, 4, 5, 4, 5, 5 };

		Set<Integer> tmp = new LinkedHashSet<Integer>();
		for (Integer each : array) {
			tmp.add(each);
		}
		System.out.println("tmp::" + tmp);
		// ////////////////

		HashMap<Integer, Integer> duplicates = new HashMap<Integer, Integer>();
		for (int i = 0; i < array.length; i++) {
			if (duplicates.containsKey(array[i])) {
				int numberOfOccurances = duplicates.get(array[i]);
				System.out.println("numberOfOccurances::" + numberOfOccurances);
				duplicates.put(array[i], (numberOfOccurances + 1));
			} else {
				duplicates.put(array[i], 1);
			}
		}
		Iterator<Integer> keys = duplicates.keySet().iterator();
		System.out.print("Duplicates : ");
		while (keys.hasNext()) {
			int k = keys.next();
			if (duplicates.get(k) > 1) {
				System.out.print(" " + k);
			}
		}
	}

}
