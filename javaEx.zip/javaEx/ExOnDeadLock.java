package javaEx;

public class ExOnDeadLock {
	public static void main(String[] args) {
		
		final String name1="rafi";
		final String name2="khan";

		Thread t1 = new Thread(){
			public void run(){
				synchronized (name1) {
					System.out.println("Thread1 Loked resource1");
					try{
					Thread.sleep(100);
					}catch(Exception ex){}
				
				synchronized (name2) {
					System.out.println("Thread1 Loked resource2");
				}
			}
		}
	};
	
	Thread t2 = new Thread(){
		public void run(){
			synchronized (name2) {
				System.out.println("Thread1 Loked resource2");
				try{
				Thread.sleep(100);
				}catch(Exception ex){}
			
			synchronized (name1) {
				System.out.println("Thread1 Loked resource1");
			}
		}
	}
};
			
			t1.start();
			t2.start();
			
			
		}
	}


