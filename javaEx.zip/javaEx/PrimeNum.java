package javaEx;

public class PrimeNum {
	public static void main(String[] ar) {
		int n = 100;
		int count = 0;
		int num = 0;
		System.out.println("prime numbers between 1 to 100 are");
		for (int i = 2; i <= n; i++) {
			for (int j = 2; j <= i; j++) {
				if (i % j == 0) {
					count++;
				}
			}
			if (count == 1) {
				System.out.println(i);
				num++;
			}
			count = 0;
		}
		System.out.println("count of prime numbers is" + num);
	}

}
