package javaEx;

public class MyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	MyException()
	{
		
	}
	MyException(String st)
	{
		System.err.println(st);
	}
}
