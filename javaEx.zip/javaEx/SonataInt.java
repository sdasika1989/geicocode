package javaEx;


public  class SonataInt {
	
	 public  double name(int i) throws Exception {
		return 0;
	}
	 /*{
		System.out.println("hello");
		return 1;
		
	}*/
	/*public int name(int i) {
		return 1;
	}*/


}

 abstract class   SonataInterview extends SonataInt{
	public  abstract double  name(int i);
	/*{
		return 0;
	}*/
	
	/*{
		return 1;
//		return 1;
	}*/
	
	//Which one is correct
//	SonataInt sonataInt = new SonataInt();
//	SonataInt sonataInt1 = new SonataInterview();
//	SonataInterview si= new  SonataInterview();
//	SonataInterview st = new SonataInt();
}