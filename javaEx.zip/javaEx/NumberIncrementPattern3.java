package javaEx;

class NumberIncrementPattern3
{
  public static void main(String[] args)
  {
    int number = 10;
    for(int i = 1 ; i<= number ; i++)
    {
      for(int j = 0; j<i ; j ++)
      {
        System.out.print((j+1)+" ");
        }
      System.out.println();
    }
  }
}

/*
1 
1 2 
1 2 3 
1 2 3 4 
1 2 3 4 5 
1 2 3 4 5 6 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 8 
1 2 3 4 5 6 7 8 9 
1 2 3 4 5 6 7 8 9 10 

*/