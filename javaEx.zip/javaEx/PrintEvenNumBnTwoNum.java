package javaEx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
 
public class PrintEvenNumBnTwoNum {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter M value::");
		int m=Integer.parseInt(br.readLine());
		System.out.println("Enter N value::");
		int n=Integer.parseInt(br.readLine());
		do{
			int i=m%2;
			if(i==0)
				System.out.println("\t"+m);
			m++;
		}while(m<n);
		
	}
}
