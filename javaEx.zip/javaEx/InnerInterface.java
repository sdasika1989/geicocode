package javaEx;
//Can we write interface in another interface?
public interface InnerInterface {
	
	public interface interfaceInner{
		
	}

}
