package javaEx;

public class ThreadRunnable implements Runnable{
	ThreadRunnable()
	{
		
	}
	@Override
	public void run()
	{
		for(int i=0;i<100;i++)
		{
			System.out.println(i);
		}
	}
	public static void main(String[] ar)
	{
		ThreadRunnable tr=new ThreadRunnable();
		Thread th=new Thread(tr);
		th.start();
	}

}
