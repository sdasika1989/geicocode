package javaEx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SumOfDigits {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=0,sum=0,d=0;
		System.out.println("Enter any Number::");
		n=Integer.parseInt(br.readLine());
		do {
			d=n%10;
			sum=sum+d;
			n=n/10;
		} while (n>0);
		System.out.println("Sum of Digits::"+sum);
		
	}
}
