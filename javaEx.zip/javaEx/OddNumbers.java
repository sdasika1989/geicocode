package javaEx;

public class OddNumbers {
	public static void main(String[] args) {
		int n=1;
		while (n<100) {
			
			n=n+2;
			System.out.println("n value1::"+n);
			
		}
	}

}
