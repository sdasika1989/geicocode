package javaEx;
 
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
 
public class SortArrayList {
 
    public static void main(String... args)
    {
 
            List<String> list = new ArrayList<String>();
 
            list.add("India");
            list.add("United States");
            list.add("Malaysia");
            list.add("Australia");
            list.add("Lundon");
 
            Collections.sort(list);
 
            /*for(String temp: list)
            {
                System.out.println("Countries : "+temp);
            }*/
            System.out.println(list);
    }
}