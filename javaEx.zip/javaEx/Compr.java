package javaEx;

import java.util.Comparator;
import java.util.TreeSet;

public class Compr implements Comparable<Object>{
	
	int eid;
	public Compr(int eid) {

		this.eid=eid;
	}
	public String  toString(){
		return "E:"+eid;

	}
	public int compareTo(Object obj) {
		
		int eid = this.eid;
		Compr e2= (Compr)obj;
		int eid2= e2.eid;
		if (eid < eid2) 
		return -1;
		else if (eid > eid2) 
			return +1;
		else 
			return 0;
		}
}
 class Comper{
	public static void main(String[] args) {
		Compr e3= new Compr(200);
		Compr e4 = new Compr(300);
		Compr e5 = new Compr(400);
		Compr e6 = new Compr(500);
		Compr e7 = new Compr(600);
		
		TreeSet<Compr> t1 = new TreeSet<Compr>();
		t1.add(e3);
		t1.add(e4);
		t1.add(e5);
		t1.add(e6);
		t1.add(e7);
		System.out.println("t1"+t1);
		TreeSet<Compr> t2= new TreeSet<Compr>(new MyComparator());
		t2.add(e7);
		t2.add(e3);
		t2.add(e4);
		t2.add(e5);
		t2.add(e6);
		System.out.println("Common Element:"+t1.retainAll(t2));
		
		System.out.println("t2:"+t2);
	}
}

class MyComparator implements Comparator<Object>
{
	public int compare(Object obj1,Object obj2){
		Compr  e1= (Compr)obj1;
		Compr  e2= (Compr)obj2;
		return e2.compareTo(e1);
	}
}
