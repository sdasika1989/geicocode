package javaEx;

public class PascalTriangle 
{
	public static void main(String[] args)
	{
		int spaceCount = 20;
		int number = 10;
		for (int i = 0; i < number; i++) 
		{

			int asciiNumber = 64;
			for (int j = 1; j <= spaceCount - i ; j++) 
			{
				System.out.print(" ");
			}
			for (int k = 1; k < i+1; k++)
			{
				asciiNumber = asciiNumber+1;
				System.out.print((char) (asciiNumber)+" ");
			}
			System.out.println();
		}
		
	}
}



/*

                    
                   A 
                  A B 
                 A B C 
                A B C D 
               A B C D E 
              A B C D E F 
             A B C D E F G 
            A B C D E F G H 
           A B C D E F G H I 


*/