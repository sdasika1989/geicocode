package javaEx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class NumIsSquareOrNot {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		int i=0,x=0;
		System.out.println("Enter a Number::");
		i=Integer.parseInt(br.readLine());
		x=(int) Math.sqrt(i);
		if (i==(x*x)) {
			System.out.println("perfect square ");
		}else {
			System.out.println("not a perfect sqare value");
		}
		
	}

}
