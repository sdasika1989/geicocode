package javaEx;

public class SeriesOfNumbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
 
		int a=0,b=1,c=a+b;
		System.out.println(a+" and "+b);
		while(c<=100){
			a=b;//1
			b=c;//2
			c=a+b;
			System.out.println(a+" and "+b+"="+c);
		}
		
	}

}
