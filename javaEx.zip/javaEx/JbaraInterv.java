package javaEx;

public class JbaraInterv {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//System.out.println(new JbaraInterv().name());
	}
	public static void name() {
		try{
//			statement1;
		}catch(Exception e){
//			statement2;
		}
		
	}

}//0/p

