package javaEx;

import java.util.TreeSet;

public class ExOnTreeSet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//Tree set allows only Homogeneous data elements
		TreeSet ts= new TreeSet();
		System.out.println("1-"+ts);
		ts.add("afd");
		System.out.println("3-"+ts);
		ts.add(6); // Will give error
		// " java.lang.ClassCastException: java.lang.String cannot be cast to java.lang.Integer"
		System.out.println("2-"+ts);
	}
}
