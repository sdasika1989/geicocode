package javaEx;
//
//interface A {}
//class B implements A {}
//
//
////2 Scenario 
// class A{} 
//class B extends A{}
// 
//// 3 Scenario
//
//  abstract class A{} 
//class B extends A{}
// 
//
//public class JbaraInte {
//	public static void main(String[] args) {
//		A a = new B();//For the above 3 scenarios are correct ot not for this statemetn
//		System.out.println(a);
//	}
//
//}

class A{
	public static int x =5;
	
	
	public void value(){
//		int x=2;
		System.out.println("x value"+x);
	}
}

public class JbaraInte{
	public static void main(String[] args) {
		A a = new A();
		a.value();
	}
}
