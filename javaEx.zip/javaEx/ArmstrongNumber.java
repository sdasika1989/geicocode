package javaEx;


public class ArmstrongNumber {
	
	public static void main(String...args) {
		
		int n=153,c=0,a,d;
		d=n;
		while(n>0){
			a=n%10;
			System.out.println("a:"+a);
			n=n/10;
			System.out.println("n"+n);
			c=c+(a*a*a);
			System.out.println("C"+c);
		}
		if(d==c)
			System.out.println("armstrong number");
		else
			System.out.println("not armstrong number");
		
	}

}