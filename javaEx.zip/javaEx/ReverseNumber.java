package javaEx;

import java.util.Scanner;

public class ReverseNumber {
	int a=0;
	int revNum=0;
	
	public int revNum(int num)
	{  		
		while(num>0)
		{
		a=num%10;
		revNum=(revNum*10)+a;
       num=num/10;
		
		}
		return revNum;
		
	}public static void main(String[] ar)
	{
	 Scanner scan=new Scanner(System.in);
	 System.out.println("enter number to find reverse number");
	 int num=scan.nextInt();
	 ReverseNumber rn=new ReverseNumber();
	  System.out.println(rn.revNum(num));
	}

}
