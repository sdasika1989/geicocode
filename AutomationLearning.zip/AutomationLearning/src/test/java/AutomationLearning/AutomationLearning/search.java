package AutomationLearning.AutomationLearning;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;

import org.openqa.selenium.*;

public class search{
static WebDriver driver = null;
public static void search_string(DataTable d1) throws IOException
{
	String searchString = d1.raw().get(1).get(0);
			int size=0;
	driver.findElement(By.id("lst-ib")).sendKeys(searchString);
	List<WebElement> searchElements= driver.findElements(By.xpath("//li[@role='presentation']"));
	for(WebElement item:searchElements){
		if(item.getText().contains("aviva")){
		System.out.println("item text:"+item.getText());
		size++;
		}
	}
	System.out.println("size:"+size);
	driver.quit();
}

public static void invokeBrowser() throws IOException{
	Properties prop= new Properties();
	FileInputStream fi=new FileInputStream("src\\main\\java\\AutomationLearning\\AutomationLearning\\testProp.properties");
	prop.load(fi);
	String browser=prop.getProperty("browser");
	if(browser.equalsIgnoreCase("Chrome")){
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	}if(browser.equalsIgnoreCase("Firefox")){
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	driver.get(prop.getProperty("url"));
}
	
}
