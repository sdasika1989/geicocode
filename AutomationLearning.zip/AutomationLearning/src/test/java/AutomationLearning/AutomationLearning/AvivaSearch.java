package AutomationLearning.AutomationLearning;

import cucumber.api.DataTable;
import cucumber.api.PendingException;

import cucumber.api.java.en.*;


public class AvivaSearch {

@Given("^User opens home page$")
public void User_opens_home_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	search.invokeBrowser();
}

@When("^User searches for Aviva keyword in search field$")
public void user_searches_for_Aviva_keyword_in_search_field(DataTable d1) throws Throwable {
 search.search_string(d1);
}

@Then("^Search results should be retured$")
public void search_results_should_be_retured() throws Throwable {
	System.out.println("Completed");
    //throw new PendingException();
}


}
